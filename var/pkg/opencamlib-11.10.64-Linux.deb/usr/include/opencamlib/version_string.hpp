//version_string.hpp - written by cmake. changes will be lost!
#ifndef VERSION_STRING
#define VERSION_STRING "11.10-64-g89c21a2"
#endif
